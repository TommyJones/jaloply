library(testthat)
library(text2vec)
data("movie_review")
test_check("text2vec")
