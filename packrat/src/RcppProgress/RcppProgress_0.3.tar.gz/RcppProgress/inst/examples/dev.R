library(devtools)

load_all('inst/examples/RcppProgressArmadillo/')